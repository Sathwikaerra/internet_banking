import React from 'react';

const MyQueries: React.FC = () => (
    <div className="bg-white border border-slate-200 rounded-xl shadow p-6 space-y-4">
        <h3 className="text-xl font-semibold text-slate-800">My Queries</h3>
        <p className="text-slate-600">Track or raise queries related to your transfers.</p>
        <div className="space-y-3">
            {[1, 2, 3].map((i) => (
                <div key={i} className="p-4 border border-slate-200 rounded-lg">
                    <div className="flex items-center justify-between">
                        <div className="font-semibold text-slate-800">Query #{i}120</div>
                        <span className="text-xs px-2 py-1 rounded-full bg-amber-100 text-amber-700">Open</span>
                    </div>
                    <p className="text-sm text-slate-600 mt-1">Status of transfer to Vendor {i}</p>
                </div>
            ))}
        </div>
        <button className="bg-slate-800 text-white px-4 py-2 rounded-lg font-semibold hover:bg-slate-900 transition">Raise new query</button>
    </div>
);

export default MyQueries;

