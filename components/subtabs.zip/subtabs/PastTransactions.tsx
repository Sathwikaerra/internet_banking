import React from 'react';

const PastTransactions: React.FC = () => (
    <div className="bg-white border border-slate-200 rounded-xl shadow p-6 space-y-4">
        <h3 className="text-xl font-semibold text-slate-800">Past Transactions</h3>
        <p className="text-slate-600">View your historical transfers and download statements.</p>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {[1, 2, 3, 4].map((i) => (
                <div key={i} className="p-4 border border-slate-200 rounded-lg hover:border-blue-400 hover:shadow-sm transition">
                    <div className="flex items-center justify-between">
                        <div>
                            <div className="font-semibold text-slate-800">Transaction #{i}234</div>
                            <div className="text-sm text-slate-500">Paid to John Doe • 12 Jan 2024</div>
                        </div>
                        <span className="text-green-600 font-semibold">-$250.00</span>
                    </div>
                </div>
            ))}
        </div>
    </div>
);

export default PastTransactions;

