import React from 'react';

const SetPrimaryAccount: React.FC = () => (
    <div className="bg-white border border-slate-200 rounded-xl shadow p-6 space-y-4">
        <h3 className="text-xl font-semibold text-slate-800">Set Primary Account</h3>
        <p className="text-slate-600">Choose the default account for transfers.</p>
        <div className="space-y-3">
            {['Savings - XXXX 2020', 'Current - XXXX 5544'].map((acc) => (
                <label key={acc} className="flex items-center gap-3 p-4 border border-slate-200 rounded-lg">
                    <input type="radio" name="primary-account" className="w-4 h-4 text-blue-600" />
                    <span className="text-slate-800 font-semibold">{acc}</span>
                </label>
            ))}
        </div>
        <button className="bg-blue-600 text-white px-4 py-2 rounded-lg font-semibold hover:bg-blue-700 transition">Save primary account</button>
    </div>
);

export default SetPrimaryAccount;

