import React from 'react';

const ManagePayees: React.FC = () => (
    <div className="bg-white border border-slate-200 rounded-xl shadow p-6 space-y-4">
        <h3 className="text-xl font-semibold text-slate-800">Manage Payees</h3>
        <p className="text-slate-600">Add, edit, or remove saved payees.</p>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            {['Alice', 'Bob', 'Charlie'].map((name) => (
                <div key={name} className="p-4 border border-slate-200 rounded-lg space-y-2">
                    <div className="font-semibold text-slate-800">{name}</div>
                    <div className="text-sm text-slate-500">Acct: XXXX 1234</div>
                    <div className="flex gap-2">
                        <button className="text-blue-600 text-sm font-semibold">Edit</button>
                        <button className="text-red-600 text-sm font-semibold">Remove</button>
                    </div>
                </div>
            ))}
        </div>
        <button className="mt-2 inline-flex items-center gap-2 text-sm font-semibold text-blue-700">+ Add new payee</button>
    </div>
);

export default ManagePayees;

