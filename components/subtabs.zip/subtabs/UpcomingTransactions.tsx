import React from 'react';

const UpcomingTransactions: React.FC = () => (
    <div className="bg-white border border-slate-200 rounded-xl shadow p-6 space-y-4">
        <h3 className="text-xl font-semibold text-slate-800">Upcoming Transactions</h3>
        <p className="text-slate-600">Scheduled transfers and standing instructions.</p>
        <div className="space-y-3">
            {[1, 2].map((i) => (
                <div key={i} className="p-4 border border-slate-200 rounded-lg flex items-center justify-between">
                    <div>
                        <div className="font-semibold text-slate-800">Electricity Bill</div>
                        <div className="text-sm text-slate-500">Executes on 28 Feb 2024</div>
                    </div>
                    <span className="text-slate-700 font-semibold">$120.00</span>
                </div>
            ))}
        </div>
    </div>
);

export default UpcomingTransactions;

